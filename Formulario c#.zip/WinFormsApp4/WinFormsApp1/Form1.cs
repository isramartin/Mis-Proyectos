
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;


namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        String line, lectura;
        private string rowHashFilePath = "C:\\Users\\52986\\source\\repos\\WinFormsApp4\\checksum.txt";
        private string currentRowHash = null;
        public Form1()
        {
            InitializeComponent();
            VerificarIntegridadDocumento();
        }


        private void VerificarIntegridadDocumento()
        {
            string savedRowHash = null;

            try
            {
                savedRowHash = File.ReadAllText(rowHashFilePath);
            }
            catch (FileNotFoundException)
            {
                // El archivo no existe, puedes manejar esto seg�n tus necesidades
                MessageBox.Show("El archivo de hash no existe. La integridad no se puede verificar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Calcular el hash del archivo checksum.txt actual
            string currentFileHash = CalcularHashArchivo(rowHashFilePath);

            if (currentFileHash != savedRowHash)
            {
                MessageBox.Show("El documento ha sido alterado desde fuera de la aplicaci�n. No conf�e en los datos guardados.", "Documento Alterado", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Puedes tomar medidas adicionales aqu�, como no continuar con la operaci�n o cerrar la aplicaci�n.
            }
            else
            {
                MessageBox.Show("El documento es v�lido.", "Documento V�lido", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private string CalcularHashArchivo(string filePath)
        {
            using (MD5 md5 = MD5.Create())
            {
                byte[] hashBytes = md5.ComputeHash(File.ReadAllBytes(filePath));
                return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Obtener los datos de los controles
            string Nombre = textBox1.Text;
            string A_Paterno = textBox2.Text;
            string A_Materno = textBox3.Text;
            string Edad = textBox4.Text;
            string Carrera = comboBox1.SelectedItem.ToString();
            string Sexo = radioButton1.Checked ? "HOMBRE" : "MUJER";
            string Materias_Favoritas = "";
            //string[] materias = {"", "", ""};


            if (checkBox1.Checked)
            {
                Materias_Favoritas += "BASE DE DATOS,";
            }
            else
            {
                Materias_Favoritas += ",";
            }

            if (checkBox2.Checked)
            {
                Materias_Favoritas += "PROGRAMACION,";
            }
            else
            {
                Materias_Favoritas += ",";
            }
            if (checkBox3.Checked)
            {
                Materias_Favoritas += "CALCULO INTEGRAL";
            }
            else
            {
                Materias_Favoritas += ",";
            }

            // Crear una cadena con todos los datos separados por comas
            string csvData = $"{Nombre},{A_Paterno},{A_Materno},{Edad},{Carrera},{Sexo},{Materias_Favoritas}";

            // MessageBox.Show($"Datos agregados al chivo exitosamente", "texto", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Ruta del archivo CSV
            string filePath = "C:\\Users\\52986\\source\\repos\\WinFormsApp4\\datos.txt";

            // Calcular el hash MD5 de los datos m�s la palabra "isra"
            using (MD5 md5 = MD5.Create())
            {
                byte[] hashBytes = md5.ComputeHash(Encoding.UTF8.GetBytes(csvData + "isra"));
                string hashValue = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();

                // Agregar el hash al final de los datos
                csvData += $",{hashValue}";
            }

            // Calcula el hash MD5 de las filas
            using (MD5 md5 = MD5.Create())
            {
                byte[] rowHashBytes = md5.ComputeHash(Encoding.UTF8.GetBytes(csvData));
                string rowHashValue = BitConverter.ToString(rowHashBytes).Replace("-", "").ToLower();

                // Guarda el hash de las filas en un archivo
                string rowHashFilePath = "C:\\Users\\52986\\source\\repos\\WinFormsApp4\\checksum.txt";
                File.WriteAllText(rowHashFilePath, rowHashValue);
            }



            // Escribir los datos en el archivo CSV
            try
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine(csvData);
                }


                MessageBox.Show("Datos guardados en el archivo exitosamente.", "Datos Guardados", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar los datos: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            // Recalcular y guardar el hash del archivo checksum.txt
            string newFileHash = CalcularHashArchivo(rowHashFilePath);
            File.WriteAllText(rowHashFilePath, newFileHash);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox5.Text = "0";
            button2.Enabled = false;


        }

        private void button3_Click(object sender, EventArgs e)
        {
            int num = int.Parse(textBox5.Text);
            num++;
            int c = 1;
            textBox5.Text = num.ToString();

            // Obt�n el n�mero total de l�neas en el archivo CSV
            int lineasDelDocumento = File.ReadLines("C:\\Users\\52986\\source\\repos\\WinFormsApp4\\datos.txt").Count();

            if (num > 1)
            {
                button2.Enabled = true;
            }

            try
            {
                // Pass the file path and file name to the StreamReader constructor
                using (StreamReader sr = new StreamReader("C:\\Users\\52986\\source\\repos\\WinFormsApp4\\datos.txt"))
                {
                    // Continue to read until you reach the desired line or end of file
                    while (c < num && sr.ReadLine() != null)
                    {
                        c++;
                    }

                    // Leer la l�nea deseada y almacenarla en 'lectura'
                    if (c == num)
                    {
                        lectura = sr.ReadLine();
                    }
                    sr.Close();
                }



                if (!string.IsNullOrEmpty(lectura))
                {
                    string[] partes = lectura.Split(",");
                    string data = string.Join(",", partes.Take(partes.Length - 1));
                    string hashFromFile = partes[partes.Length - 1];

                    using (MD5 md5 = MD5.Create())
                    {
                        byte[] dataBytes = Encoding.UTF8.GetBytes(data + "isra");
                        byte[] hashBytes = md5.ComputeHash(dataBytes);
                        string hashValue = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();


                        if (hashValue != hashFromFile)
                        {
                            // Los datos han sido alterados
                            MessageBox.Show("el archivo fue alterado." + $"[{hashFromFile}][{hashValue}]", "Modificacion de Archivo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            
                        }
                    }
                }

                // Asignar los valores de 'lectura' a los controles del formulario
                if (!string.IsNullOrEmpty(lectura))
                {
                    string[] partes = lectura.Split(",");
                    textBox1.Text = partes[0];
                    textBox2.Text = partes[1];
                    textBox3.Text = partes[2];
                    textBox4.Text = partes[3];
                    comboBox1.Text = partes[4];
                    radioButton1.Checked = (partes[5] == "HOMBRE");
                    radioButton2.Checked = (partes[5] == "MUJER");
                    string[] asignaturas = { "BASE DE DATOS", "PROGRAMACION", "CALCULO INTEGRAL" };

                    // Leer las materias seleccionadas
                    //string[] materias = partes[6].Split('+');

                    for (int i = 0; i < asignaturas.Length; i++)
                    {
                        if (partes[6] == asignaturas[0])
                        {
                            checkBox1.Checked = true;
                        }
                        else
                        {
                            checkBox1.Checked = false;
                        }
                    }

                    for (int i = 0; i < asignaturas.Length; i++)
                    {
                        if (partes[7] == asignaturas[1])
                        {
                            checkBox2.Checked = true;
                        }
                        else
                        {
                            checkBox2.Checked = false;
                        }
                    }

                    for (int i = 0; i < asignaturas.Length; i++)
                    {
                        if (partes[8] == asignaturas[2])
                        {
                            checkBox3.Checked = true;
                        }
                        else
                        {
                            checkBox3.Checked = false;
                        }
                    }

                }

                else
                {

                    MessageBox.Show("No se encontr� el registro especificado.", "Registro no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }



                // Deshabilitar el bot�n 3 cuando llegues a la �ltima l�nea del documento
                if (c == lineasDelDocumento)
                {
                    button3.Enabled = false;
                }
            }
            catch (Exception error)
            {
                MessageBox.Show($"Error al leer el archivo: {error.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            int num = int.Parse(textBox5.Text);
            num--;
            int c = 1;
            textBox5.Text = num.ToString();
            // Obt�n el n�mero total de l�neas en el archivo CSV
            int lineasDelDocumento = File.ReadLines("C:\\Users\\52986\\source\\repos\\WinFormsApp4\\datos.txt").Count();

            if (num <= 1)
            {
                button2.Enabled = false;
            }

            try
            {
                //Pass the file path and file name to the StreamReader constructor
                StreamReader sr = new StreamReader("C:\\Users\\52986\\source\\repos\\WinFormsApp4\\datos.txt");
                //Read the first line of text

                line = sr.ReadLine();
                lectura = line;


                //Continue to read until you reach end of file
                while (line != null)
                {
                    //Read the next line
                    line = sr.ReadLine();
                    c++;
                    if (c == num)
                    {
                        lectura = line;

                    }


                }

                //close the file
                sr.Close();

                if (!string.IsNullOrEmpty(lectura))
                {
                    string[] partes = lectura.Split(",");
                    string data = string.Join(",", partes.Take(partes.Length - 1));
                    string hashFromFile = partes[partes.Length - 1];

                    using (MD5 md5 = MD5.Create())
                    {
                        byte[] dataBytes = Encoding.UTF8.GetBytes(data + "isra");
                        byte[] hashBytes = md5.ComputeHash(dataBytes);
                        string hashValue = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();

                        if (hashValue != hashFromFile)
                        {
                            // Los datos han sido alterados
                            MessageBox.Show("el archivo fue alterado." + $"[{hashFromFile}][{hashValue}]", "Modificacion de Archivo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            // Puedes decidir qu� hacer en caso de anomal�a, como mostrar un mensaje o no avanzar al siguiente registro.
                        }
                    }


                }

            }



            catch (Exception error)
            {
                Console.WriteLine("Exception: " + error.Message);
            }
            finally
            {
                //MessageBox.Show(lectura);
                if (!string.IsNullOrEmpty(lectura))
                {
                    string[] partes = lectura.Split(",");
                    textBox1.Text = partes[0];
                    textBox2.Text = partes[1];
                    textBox3.Text = partes[2];
                    textBox4.Text = partes[3];
                    comboBox1.Text = partes[4];
                    radioButton1.Checked = (partes[5] == "HOMBRE");
                    radioButton2.Checked = (partes[5] == "MUJER");
                    string[] asignaturas = { "BASE DE DATOS", "PROGRAMACION", "CALCULO INTEGRAL" };


                    for (int i = 0; i < asignaturas.Length; i++)
                    {
                        if (partes[6] == asignaturas[0])
                        {
                            checkBox1.Checked = true;
                        }
                        else
                        {
                            checkBox1.Checked = false;
                        }
                    }

                    for (int i = 0; i < asignaturas.Length; i++)
                    {
                        if (partes[7] == asignaturas[1])
                        {
                            checkBox2.Checked = true;
                        }
                        else
                        {
                            checkBox2.Checked = false;
                        }
                    }

                    for (int i = 0; i < asignaturas.Length; i++)
                    {
                        if (partes[8] == asignaturas[2])
                        {
                            checkBox3.Checked = true;
                        }
                        else
                        {
                            checkBox3.Checked = false;
                        }
                    }

                    // Leer las materias seleccionadas
                    /* string[] materias = partes[6].Split('+');
                     foreach (string materia in materias)
                     {
                         //string trimmedMateria = materia.Trim();
                         if (materia.Equals("BASE DE DATOS", StringComparison.OrdinalIgnoreCase))
                         {
                             checkBox1.Checked = true;
                         }
                         if (materia.Equals("PROGRAMACION", StringComparison.OrdinalIgnoreCase))
                         {
                             checkBox2.Checked = true;
                         }
                         if (materia.Equals("CALCULO INTEGRAL", StringComparison.OrdinalIgnoreCase))
                         {
                             checkBox3.Checked = true;
                         }
                     }*/ 
                }
            }

            if (num >= 1)
            {
                button3.Enabled = true;
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {

            // Obtener el n�mero de registro que se desea actualizar
            if (!int.TryParse(textBox5.Text, out int num))
            {
                MessageBox.Show("Ingrese un n�mero de registro v�lido.");
                return;
            }

            // Leer todas las l�neas del archivo CSV
            string[] lineas = File.ReadAllLines("C:\\Users\\52986\\source\\repos\\WinFormsApp4\\datos.txt");

            // Verificar si el n�mero de registro seleccionado es v�lido
            if (num > 0 && num <= lineas.Length)
            {
                // Obtener la l�nea a actualizar
                string lineaAActualizar = lineas[num - 1]; // Restamos 1 porque el �ndice es 0-based

                // Obtener los datos que deseas actualizar
                string Nombre = textBox1.Text;
                string A_Paterno = textBox2.Text;
                string A_Materno = textBox3.Text;
                string Edad = textBox4.Text;
                string Carrera = comboBox1.SelectedItem.ToString();
                string Sexo = radioButton1.Checked ? "HOMBRE" : "MUJER";
                string Materias_Favoritas = "";

                if (checkBox1.Checked)
                {
                    Materias_Favoritas += "BASE DE DATOS,";
                }
                else
                {
                    Materias_Favoritas += ",";
                }

                if (checkBox2.Checked)
                {
                    Materias_Favoritas += "PROGRAMACION,";
                }
                else
                {
                    Materias_Favoritas += ",";
                }

                if (checkBox3.Checked)
                {
                    Materias_Favoritas += "CALCULO INTEGRAL";
                }
                else
                {
                    Materias_Favoritas += ",";
                }

                // Crear una cadena con todos los datos separados por comas
                string csvData = $"{Nombre},{A_Paterno},{A_Materno},{Edad},{Carrera},{Sexo},{Materias_Favoritas}";

                // Calcular el hash MD5 de los datos m�s la palabra "isra"
                using (MD5 md5 = MD5.Create())
                {
                    byte[] hashBytes = md5.ComputeHash(Encoding.UTF8.GetBytes(csvData + "isra"));
                    string hashValue = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();

                    // Agregar el hash al final de los datos
                    csvData += $",{hashValue}";
                }

                // Actualizar la l�nea con los nuevos datos
                lineas[num - 1] = csvData;

                    

                try
                {
                    // Escribir todas las l�neas actualizadas de vuelta al archivo
                    File.WriteAllLines("C:\\Users\\52986\\source\\repos\\WinFormsApp4\\datos.txt", lineas);

                    MessageBox.Show("Registro actualizado correctamente.", "Actualizaci�n Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al actualizar el registro: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            else
            {
                MessageBox.Show("N�mero de registro no v�lido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Limpiar los controles de edici�n
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            comboBox1.SelectedIndex = -1; // Deseleccionar el elemento en ComboBox
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;

            // Habilitar los controles si est�n deshabilitados
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            comboBox1.Enabled = true;
            radioButton1.Enabled = true;
            radioButton2.Enabled = true;
            checkBox1.Enabled = true;
            checkBox2.Enabled = true;
            checkBox3.Enabled = true;
        }
    }
}